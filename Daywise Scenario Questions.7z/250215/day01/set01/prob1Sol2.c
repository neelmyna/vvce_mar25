#include<stdio.h>
#include<string.h>

void readEmployee(int* p_id, char* name, int* p_attendance, float* p_salary) {
    printf("Enter id:");
    scanf("%d", p_id);

    printf("Enter name:");
    scanf("%s", name);

    printf("Enter total days worked:");
    scanf("%d", p_attendance);

    printf("Enter basic salary:");
    scanf("%f", p_salary);
}

float calculateBonus(int attendance, float salary) {
    float bonus = 0.0f;
    if(attendance > 25) {
        bonus = (salary / 100.0f) * 5.0f;
    } else if(attendance < 10) {
        bonus = -1.0f * (salary / 100.0f) * 50.0f;
    }
    return bonus;
}

void categorizeEmployee(char* category, int attendance) {
    if(attendance > 25) {
        strcpy(category, "Excellent");
    } else if(attendance <= 25 && attendance >= 15) {
        strcpy(category, "Good");
    } else {
        strcpy(category, "Needs Improvement");
    }
}

void printPayroll(float gross_salary, float bonus, char* category) {
    printf("Final Salary is %.2f\n", gross_salary);
    if(bonus > 0) {
        printf("Attendance Bonus is %.2f\n", bonus);
    }
    printf("Employee Performance category is %s", category);
}

int main() {
    int id;
    char name[255];//name is char arr / str ie char arr == str
    int attendance;
    float salary;
    readEmployee(&id, name, &attendance, &salary);

    float gross_salary = 0.0f;
    float bonus = 0.0f;
    char category[50];
    
    bonus = calculateBonus(attendance, salary);
    gross_salary = salary + bonus;
    categorizeEmployee(category, attendance);

    printPayroll(gross_salary, bonus, category);

    return 0;
}