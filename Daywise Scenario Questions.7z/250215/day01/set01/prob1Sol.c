#include<stdio.h>
#include<string.h>
int main() {
    int id;
    char name[255];//name is char arr / str ie char arr == str
    int attendance;
    float salary;
    printf("Enter id:");
    scanf("%d", &id);

    printf("Enter name:");
    scanf("%s", &name);

    printf("Enter total days worked:");
    scanf("%d", &attendance);

    printf("Enter basic salary:");
    scanf("%f", &salary);

    float gross_salary = 0.0f;
    float bonus = 0.0f;
    char category[50];
    
    if(attendance > 25) {
        bonus = (salary / 100.0f) * 5.0f;
    } else if(attendance < 10) {
        bonus = -1.0f * (salary / 100.0f) * 50.0f;
    }
    gross_salary = salary + bonus;

        
    if(attendance > 25) {
        strcpy(category, "Excellent");
    } else if(attendance <= 25 && attendance >= 15) {
        strcpy(category, "Good");
    } else {
        strcpy(category, "Needs Improvement");
    }

    printf("Final Salary is %.2f\n", gross_salary);
    if(bonus > 0) {
        printf("Attendance Bonus is %.2f\n", bonus);
    }
    printf("Employee Performance category is %s", category);

    return 0;
}